import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-table',
  template: `<router-outlet></router-outlet>`
})
export class TableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
