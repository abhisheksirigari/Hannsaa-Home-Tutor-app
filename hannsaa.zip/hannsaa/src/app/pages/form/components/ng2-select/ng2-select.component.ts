import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng2-select',
  templateUrl: './ng2-select.component.html',
  styleUrls: ['./ng2-select.component.scss']
})
export class Ng2SelectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
