import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-levels-1-1',
  templateUrl: './levels-1-1.component.html',
  styleUrls: ['./levels-1-1.component.scss']
})
export class Levels11Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
