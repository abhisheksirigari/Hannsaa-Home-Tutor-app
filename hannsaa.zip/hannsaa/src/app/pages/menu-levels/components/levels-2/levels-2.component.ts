import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-levels-2',
  templateUrl: './levels-2.component.html',
  styleUrls: ['./levels-2.component.scss']
})
export class Levels2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
